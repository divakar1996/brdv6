package com.nucleus.BRDProgram;

//import java.util.HashSet;

public class Validation {
	// HashSet hs = new HashSet();
	// FILE FORMAT VALIDATION
	public boolean fileFormat(String string) {
		if (string.endsWith(".txt")) {
			return true;
		} else
			return false;
	}

	// Customer Code Validation.
	public boolean customerCodeValidation(String cusCode) {
		if (cusCode.length() <= 10 && !cusCode.isEmpty() /* && hs.add(cusCode) */)
			return true;
		else
			return false;
	}

	// Customer Name Validation
	public boolean customerNameValidation(String customerName) {
		if (customerName.matches("[a-zA-Z0-9 ]+")
				&& customerName.length() <= 30 && !customerName.isEmpty())
			return true;
		else
			return false;

	}

	// Address Validation
	public boolean validationAddress1(String add1) {
		if (add1.length() <= 100 && !add1.isEmpty())
			return true;
		else
			return false;
	}

	// Address 2 Validation
	public boolean validationAddress2(String add2) {
		if (add2.length() <= 100)
			return true;
		else
			return false;
	}

	// pincode validation
	public boolean pinCodeValidation(String pincode) {
		if (pincode.length() != 6 && pincode.isEmpty())
			return false;
		else
			return true;

	}

	// email validation
	public boolean isValidEmailCheck(String email) {
		if (email != null && email.length() <= 100) {
			EmailValidator emailValidator = new EmailValidator();
			return emailValidator.validate(email);
		} else {
			return false;
		}

	}

	// COntact validation
	public boolean contactNumberValidation(String number) {
		if (number.length() > 0 && number.length() < 20) {
			return true;
		} else
			return false;
	}

	//
	public boolean primaryContactPersonValidation(String primary) {
		if (primary.length() <= 100 && !primary.isEmpty())
			return true;
		else
			return false;

	}

	// record validation
	public boolean recordStatusValidation(String recordStatus) {
		recordStatus = recordStatus.toUpperCase();
		if (recordStatus != null && recordStatus.length() == 1) {
			if (recordStatus.length() == 1
					&& (recordStatus.equals("N") || recordStatus.equals("M")
							|| recordStatus.equals("D")
							|| recordStatus.equals("A") || recordStatus
								.equals("R"))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}

	}

	// flag validation
	public boolean flagValidation(String flag) {
		if (flag != null && flag.length() == 1) {
			if (flag.length() == 1 && (flag.equals("A") || flag.equals("I"))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public boolean createDatevalidation(String date) {
		if (!date.isEmpty())
			return true;
		else
			return false;

	}

	public boolean createByValidation(String by) {
		if (by.length() <= 30 && !by.isEmpty())
			return true;
		else
			return false;
	}

	public boolean modByvalidation(String by) {
		if (by.length() <= 30)
			return true;
		else
			return false;

	}

	public boolean authBYValidation(String auth) {
		if (auth.length() <= 30)
			return true;
		else
			return false;
	}

}
