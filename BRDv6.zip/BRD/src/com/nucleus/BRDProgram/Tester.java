package com.nucleus.BRDProgram;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Tester {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		BufferedReader bufferedReader = null;
		String line = null;

		DaoConnection daoConnection = new DaoConnection();
		// DaoConnection daoConnection=null;
		List<String> list = new ArrayList<String>();
		CustomerMasterTable cmt = new CustomerMasterTable();

		Validation validation = new Validation();
		ErrorLog errorLog = new ErrorLog();
		boolean v1 = false;
		boolean v2 = false;
		boolean v3 = false;
		boolean v4 = false;
		boolean v5 = false;
		boolean v6 = false;
		boolean v7 = false;
		boolean v8 = false;
		boolean v9 = false;
		boolean v10 = false;
		boolean fileFormat = false;
		/*
		 * boolean v10=false; boolean v11=false; boolean v12=false; boolean
		 * v13=false; boolean v14=false; boolean v15=false;
		 */

		int n;

		String fileLocation = "D:\\BRD-File Upload\\Test Cases\\";
		System.out.println("Enter file name");
		String fileName = scanner.nextLine();
		fileFormat = validation.fileFormat(fileName);

		if (fileFormat) {

			try {
				bufferedReader = new BufferedReader(new FileReader(fileLocation
						+ fileName));

				System.out.println("File Loaded Successfully..............");

				System.out.println("CHOICE*******");
				System.out
						.println("1. R For record level Rejection\n2.F for File level Rejection");
				n = scanner.nextInt();

				try {
					while ((line = bufferedReader.readLine()) != null) {
						String[] token = line.split("~", -1);

						cmt.setCustomerCode(token[0]);
						cmt.setCustomerName(token[1]);
						cmt.setCustomerAddress1(token[2]);
						cmt.setCustomerAddress2(token[3]);
						cmt.setCustomerPinCode(token[4]);
						cmt.setEmailAddress(token[5]);
						cmt.setContactNumber(token[6]);
						cmt.setPrimaryContactPerson(token[7]);
						cmt.setRecordStatus(token[8]);
						cmt.setActiveInactiveFlag(token[9]);
						cmt.setCreateDate(token[10]);
						cmt.setCreatedBy(token[11]);
						cmt.setModifiedDate(token[12]);
						cmt.setModifiedBy(token[13]);
						cmt.setAuthorizedDate(token[14]);
						cmt.setAuthorizedBy(token[15]);

						v1 = validation.customerCodeValidation(cmt
								.getCustomerCode());

						v2 = validation.customerNameValidation(cmt
								.getCustomerName());

						v3 = validation.validationAddress1(cmt
								.getCustomerAddress1());

						v4 = validation.validationAddress2(cmt
								.getCustomerAddress2());

						v5 = validation.pinCodeValidation(cmt
								.getCustomerPinCode());

						v6 = validation
								.isValidEmailCheck(cmt.getEmailAddress());
						v7 = validation.contactNumberValidation(cmt
								.getContactNumber());

						v8 = validation.primaryContactPersonValidation(cmt
								.getPrimaryContactPerson());

						v9 = validation.recordStatusValidation(cmt
								.getRecordStatus());

						v10 = validation.flagValidation(cmt
								.getActiveInactiveFlag());

						switch (n) {
						// FOR RECORD LEVEL REJECTION*********
						case 1:
							if (v1 && v2 && v3 && v4 && v5 && v6 && v7 && v8
									&& v9 && v10) {
								System.out.println(cmt);

								daoConnection.insertion(cmt);

							} else {
								errorLog.saveToFile(line);
								if (!v1) {
									errorLog.saveToFile(cmt.getCustomerCode());
								}
								if (!v2) {
									errorLog.saveToFile(cmt.getCustomerName());
								}
								if (!v3) {
									errorLog.saveToFile(cmt
											.getCustomerAddress1());
								}
								if (!v4) {
									errorLog.saveToFile(cmt
											.getCustomerAddress2());
								}
								if (!v5) {

									errorLog.saveToFile(cmt
											.getCustomerPinCode());
								}
								if (!v6) {
									errorLog.saveToFile(cmt.getEmailAddress());
								}
								if (!v7) {

									errorLog.saveToFile(cmt.getContactNumber());
								}
								if (!v8) {
									errorLog.saveToFile(cmt
											.getPrimaryContactPerson());
								}
								if (!v9) {
									errorLog.saveToFile(cmt.getRecordStatus());
								}
								if (!v10) {
									errorLog.saveToFile(cmt
											.getActiveInactiveFlag());
								}

							}

							break;
						// FOR FILE LEVEL REJECTION***********
						case 2:
							
							if(v1 && v2 && v3 && v4 && v5 && v6 && v7 && v8
									&& v9 && v10){
								daoConnection.insertion(cmt);
								errorLog.saveToFile1(line);
							}else{

								
								break;
							}
							
							/*boolean flag = true;
							if (v1 && v2 && v3 && v4 && v5 && v6 && v7 && v8
									&& v9 && v10 && flag) {
								//list.add(line);

								daoConnection.insertion(cmt);

							} else {
								if (flag == true) {
									for (int i = 0; i < list.size(); i++) {
										errorLog.saveToFile1(list.get(i));
									}
								}

							}

							flag = false;*/
							break;
						}

					}
					try {
						daoConnection.rollBack();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
					
					
					
				} catch (NumberFormatException e) {

					e.printStackTrace();
				} catch (IOException e) {

					e.printStackTrace();
				}

			} catch (FileNotFoundException e) {

				System.out
						.println("File Loading Error...............File not found.........");
			}

		} else {
			System.out
					.println("File Loading Error...............File not found.........");
		}

	}

}
